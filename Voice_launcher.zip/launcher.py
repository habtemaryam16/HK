"""
Continuous voice-activated launcher (PyAudio-free)
- Uses sounddevice to record audio snippets
- Converts snippets to sr.AudioData and uses SpeechRecognition (Google) to transcribe
- Fuzzy matches recognized text to commands in commands.json
"""

import json
import os
import subprocess
import time
from difflib import get_close_matches

import numpy as np
import sounddevice as sd
import speech_recognition as sr

# Config
COMMANDS_FILE = "commands.json"
SAMPLE_RATE = 16000           # Hz
CHANNELS = 1                  # mono
CHUNK_DURATION = 2.5          # seconds per recording slice (smaller = more responsive)
SILENCE_RETRY = 0.4           # seconds to sleep between iterations
FUZZY_CUTOFF = 0.55           # fuzzy matching cutoff (0-1)

# Load commands
def load_commands(path=COMMANDS_FILE):
    if not os.path.exists(path):
        print(f"[ERROR] {path} not found. Create commands.json next to launcher.py")
        raise SystemExit(1)
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return {k.lower(): v for k, v in data.items()}

commands = load_commands()

# Find best key for transcript
def find_command_key(transcript):
    if not transcript:
        return None
    text = transcript.lower().strip()
    # remove common verbs
    for prefix in ("open ", "start ", "launch ", "run ", "please open ", "please start "):
        if text.startswith(prefix):
            text = text[len(prefix):].strip()
            break

    # exact
    if text in commands:
        return text

    # try words combos
    words = text.split()
    for i in range(len(words)):
        cand = " ".join(words[i:]).strip()
        if cand in commands:
            return cand

    # fuzzy match
    keys = list(commands.keys())
    matches = get_close_matches(text, keys, n=1, cutoff=FUZZY_CUTOFF)
    if matches:
        return matches[0]

    # containment fallback
    for k in keys:
        if k in text or text in k:
            return k

    return None

def open_app(path):
    try:
        # Use startfile for file associations if possible
        if os.path.exists(path):
            subprocess.Popen([path], shell=False)
        else:
            # Try to start by command (e.g. 'calc.exe' or 'cmd')
            try:
                os.startfile(path)
            except Exception:
                subprocess.Popen(path, shell=True)
        print(f"[INFO] Launched: {path}")
    except Exception as e:
        print(f"[ERROR] Failed to open {path}: {e}")

def record_snippet(duration, samplerate, channels):
    """Record a short snippet and return numpy int16 array"""
    frames = int(duration * samplerate)
    # sounddevice returns float32 in range [-1, 1]
    rec = sd.rec(frames, samplerate=samplerate, channels=channels, dtype='float32')
    sd.wait()
    # convert to mono int16
    if rec.ndim > 1:
        rec = rec.mean(axis=1)
    int16 = (rec * 32767).astype(np.int16)
    return int16.tobytes()

def main_loop():
    recognizer = sr.Recognizer()
    print("Starting continuous listening (PyAudio-free). Press Ctrl+C to exit.")
    print(f"Chunk: {CHUNK_DURATION}s | Sample rate: {SAMPLE_RATE} Hz")
    try:
        while True:
            try:
                raw_bytes = record_snippet(CHUNK_DURATION, SAMPLE_RATE, CHANNELS)
                audio_data = sr.AudioData(raw_bytes, SAMPLE_RATE, 2)  # sample_width=2 (int16)
                try:
                    transcript = recognizer.recognize_google(audio_data)
                    transcript = transcript.strip()
                    if transcript:
                        print(f"[Heard] {transcript}")
                        key = find_command_key(transcript)
                        if key:
                            path = commands.get(key)
                            if path:
                                print(f"[MATCH] '{key}' -> {path}")
                                open_app(path)
                            else:
                                print(f"[WARN] Matched key '{key}' but no path found.")
                        else:
                            print("[INFO] No match for spoken phrase.")
                    else:
                        # nothing recognized
                        pass
                except sr.UnknownValueError:
                    # couldn't understand the audio
                    # silent or unintelligible
                    pass
                except sr.RequestError as e:
                    print(f"[ERROR] Speech recognition service error: {e}")
                    time.sleep(1)
            except Exception as e:
                print(f"[ERROR] Recording/processing exception: {e}")
                time.sleep(0.5)
            time.sleep(SILENCE_RETRY)
    except KeyboardInterrupt:
        print("\nExiting (Ctrl+C pressed).")

if __name__ == "__main__":
    main_loop()
